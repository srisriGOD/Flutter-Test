import 'package:flutter/material.dart';
import 'package:rolling_bottom_bar/rolling_bottom_bar.dart';
import 'package:rolling_bottom_bar/rolling_bottom_bar_item.dart';

import 'camera.dart';
import 'newsfeed.dart';
import 'peoples.dart';
import 'profile.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _pageController = PageController();

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: PageView(
          controller: _pageController,
          children: const <Widget>[
            NewsFeedScreen(),
            CameraPage(),
            PeoplesScreen(),
            ProfilePage(),
          ],
        ),
        extendBody: true,
        bottomNavigationBar: RollingBottomBar(
          color: Colors.black,
          controller: _pageController,
          flat: true,
          useActiveColorByDefault: false,
          items: const [
            RollingBottomBarItem(
              Icons.home,
              label: 'Home',
              activeColor: Colors.white,
            ),
            RollingBottomBarItem(
              Icons.camera,
              label: 'Camera',
              activeColor: Colors.white,
            ),
            RollingBottomBarItem(
              Icons.people,
              label: 'Peoples',
              activeColor: Colors.white,
            ),
            RollingBottomBarItem(
              Icons.person,
              label: 'Person',
              activeColor: Colors.white,
            ),
          ],
          enableIconRotation: true,
          onTap: (index) {
            _pageController.animateToPage(
              index,
              duration: const Duration(milliseconds: 400),
              curve: Curves.easeOut,
            );
          },
        ),
      ),
    );
  }
}

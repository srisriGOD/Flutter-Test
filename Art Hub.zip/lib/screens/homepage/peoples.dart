import 'package:flutter/material.dart';

class PeoplesScreen extends StatefulWidget {
  const PeoplesScreen({Key? key}) : super(key: key);

  @override
  _PeoplesScreenState createState() => _PeoplesScreenState();
}

class _PeoplesScreenState extends State<PeoplesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Peoples'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 10,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: const CircleAvatar(
                    backgroundImage:
                        AssetImage('assets/images/feedsimages.jpg'),
                  ),
                  title: Text('User $index'),
                  subtitle: const Text('Bio or additional info about the user'),
                  trailing: ElevatedButton(
                    onPressed: () {},
                    child: const Text('Follow'),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

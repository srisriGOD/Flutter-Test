import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class CameraPage extends StatefulWidget {
  const CameraPage({Key? key}) : super(key: key);

  @override
  _CameraPageState createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  final ImagePicker _picker = ImagePicker();
  Uint8List? _imageBytes;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: const BoxDecoration(color: Colors.white),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_imageBytes != null) ...[
              Column(
                children: [
                  Image.memory(
                    _imageBytes!,
                    height: 300,
                    width: 300,
                    fit: BoxFit.cover,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Post your arts through this',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          _showOptionsDialog(context);
                        },
                        child: const Icon(
                          Icons.camera,
                          size: 25,
                        ),
                      ),
                      const SizedBox(
                        width: 30,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          _postImage();
                        },
                        child: const Text('Post'),
                      ),
                    ],
                  )
                ],
              ),
            ] else ...[
              const Text(
                'Post your arts through this',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  _showOptionsDialog(context);
                },
                child: const Icon(
                  Icons.camera,
                  size: 70,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showOptionsDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return SimpleDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Select an option'),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
          children: [
            SimpleDialogOption(
              onPressed: () {
                Navigator.pop(context);
                _openCamera();
              },
              child: const Text('Open Camera'),
            ),
            const SizedBox(
              height: 5,
            ),
            SimpleDialogOption(
              onPressed: () {
                Navigator.pop(context);
                _pickImageFromGallery();
              },
              child: const Text('Pick from Gallery'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _openCamera() async {
    final XFile? pickedFile = await _picker.pickImage(
      source: ImageSource.camera,
    );

    if (pickedFile != null) {
      final File imageFile = File(pickedFile.path);
      final Uint8List bytes = await imageFile.readAsBytes();
      setState(() {
        _imageBytes = bytes;
      });
      print('Image from camera: ${pickedFile.path}');
    }
  }

  Future<void> _pickImageFromGallery() async {
    final XFile? pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
    );

    if (pickedFile != null) {
      final File imageFile = File(pickedFile.path);
      final Uint8List bytes = await imageFile.readAsBytes();
      setState(() {
        _imageBytes = bytes;
      });
      print('Image from gallery: ${pickedFile.path}');
    }
  }

  void _postImage() {
    // Implement logic to post the image
    // This is where you can handle the "Post" button press
    print('Image posted!');
  }
}

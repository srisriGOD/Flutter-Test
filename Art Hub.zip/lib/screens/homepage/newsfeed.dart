import 'package:flutter/material.dart';

class Artwork {
  final String caption;
  final String imageUrl;
  int likes;
  bool isCommentsVisible;
  bool isLiked;

  Artwork({
    required this.caption,
    required this.imageUrl,
    this.likes = 0,
    this.isCommentsVisible = false,
    this.isLiked = false,
  });

  void toggleLike() {
    likes += isLiked ? -1 : 1;
    isLiked = !isLiked;
  }

  void toggleComments() {
    isCommentsVisible = !isCommentsVisible;
  }
}

class NewsFeedScreen extends StatefulWidget {
  const NewsFeedScreen({Key? key}) : super(key: key);

  @override
  _NewsFeedScreenState createState() => _NewsFeedScreenState();
}

class _NewsFeedScreenState extends State<NewsFeedScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController animationController;
  late Animation<double> animation;

  @override
  void initState() {
    super.initState();

    animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    animation = Tween<double>(begin: 1, end: 1.5).animate(
      CurvedAnimation(
        parent: animationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  List<Artwork> artworks = [
    Artwork(
      imageUrl: 'assets/images/feedsimages.jpg',
      caption: 'Beautiful sunset painting',
      likes: 20,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        itemCount: artworks.length,
        itemBuilder: (context, index) {
          return _buildArtworkCard(artworks[index]);
        },
      ),
    );
  }

  Widget _buildArtworkCard(Artwork artwork) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              artwork.caption,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 200,
            child: Image.asset(
              artwork.imageUrl,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            artwork.toggleLike();
                            if (artwork.isLiked) {
                              animationController.reset();
                              animationController.forward();
                            } else {
                              animationController.reverse();
                            }
                          });
                        },
                        child: AnimatedBuilder(
                          animation: animationController,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: animation.value,
                              child: Icon(
                                Icons.favorite,
                                color: artwork.isLiked ? Colors.red : null,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${artwork.likes} Likes',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                const Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Icon(Icons.shopping_cart, color: Colors.green),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

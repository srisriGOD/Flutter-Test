import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  String? usernameError;
  String? passwordError;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          _buildBackgroundImage(),
          Center(
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                width: 300.0,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Welcome to Artistic Connect',
                      style: TextStyle(
                          fontSize: 20.0, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 20.0),
                    _buildTextField(
                      label: 'Username',
                      controller: usernameController,
                      validator: (value) {
                        if (value!.isEmpty) {
                          setState(() {
                            usernameError = 'Username is required';
                          });
                          return 'Username is required';
                        }
                        setState(() {
                          usernameError = null;
                        });
                        return null;
                      },
                      errorText: usernameError,
                    ),
                    const SizedBox(height: 12.0),
                    _buildTextField(
                      label: 'Password',
                      controller: passwordController,
                      isPassword: true,
                      validator: (value) {
                        if (value!.isEmpty) {
                          setState(() {
                            passwordError = 'Password is required';
                          });
                          return 'Password is required';
                        } else if (!_isPasswordValid(value)) {
                          setState(() {
                            passwordError =
                                'Password must contain at least one uppercase letter, one lowercase letter, one special character, and one digit';
                          });
                          return 'Invalid password';
                        }
                        setState(() {
                          passwordError = null;
                        });
                        return null;
                      },
                      errorText: passwordError,
                    ),
                    const SizedBox(height: 20.0),
                    ElevatedButton(
                      onPressed: () {
                        if (_validateForm()) {
                          // Your login logic
                        }
                      },
                      child: const Text('Login'),
                    ),
                    const SizedBox(height: 10.0),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/register');
                        },
                        child: RichText(
                          text: const TextSpan(
                            text: "Don't have an account?",
                            style: TextStyle(color: Colors.black),
                            children: [
                              WidgetSpan(
                                child: SizedBox(width: 5),
                              ),
                              TextSpan(
                                text: 'Sign Up',
                                style: TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackgroundImage() {
    return Image.asset(
      'assets/images/Art_Background.jpg',
      fit: BoxFit.cover,
      height: double.infinity,
      width: double.infinity,
    );
  }

  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    required String? Function(String?) validator,
    bool isPassword = false,
    String? errorText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 16.0),
        ),
        TextFormField(
          controller: controller,
          obscureText: isPassword,
          validator: validator,
        ),
        if (errorText != null)
          Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: Text(
              errorText,
              style: const TextStyle(color: Colors.red),
            ),
          ),
      ],
    );
  }

  bool _validateForm() {
    if (usernameController.text.isEmpty || passwordController.text.isEmpty) {
      setState(() {
        usernameError =
            usernameController.text.isEmpty ? 'Username is required' : null;
        passwordError =
            passwordController.text.isEmpty ? 'Password is required' : null;
      });
      return false;
    }

    if (!_isPasswordValid(passwordController.text)) {
      setState(() {
        passwordError =
            'Password must contain at least one 8 characters, uppercase letter, one lowercase letter, one special character, and one digit';
      });
      return false;
    }

    setState(() {
      usernameError = null;
      passwordError = null;
    });

    Navigator.pushReplacementNamed(context, '/homepage');
    return true;
  }

  bool _isPasswordValid(String password) {
    RegExp regex =
        RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{4,}$');
    return regex.hasMatch(password);
  }
}

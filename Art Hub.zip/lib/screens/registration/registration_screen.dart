import 'package:flutter/material.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({Key? key}) : super(key: key);

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  String? firstNameError;
  String? lastNameError;
  String? genderError;
  String? dobError;
  String? phoneNumberError;
  String? emailError;
  String? passwordError;
  String? confirmPasswordError;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          _buildBackgroundImage(),
          Center(
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                width: 300.0,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Create an Account',
                      style: TextStyle(
                          fontSize: 20.0, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 20.0),
                    Row(
                      children: [
                        Expanded(
                          child: _buildTextField(
                            label: 'First Name',
                            controller: firstNameController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'First Name is required';
                              }
                              return null;
                            },
                            errorText: firstNameError,
                          ),
                        ),
                        const SizedBox(width: 12.0),
                        Expanded(
                          child: _buildTextField(
                            label: 'Last Name',
                            controller: lastNameController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Last Name is required';
                              }
                              return null;
                            },
                            errorText: lastNameError,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12.0),
                    Row(
                      children: [
                        Expanded(
                          child: _buildTextField(
                            label: 'Gender',
                            controller: genderController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Gender is required';
                              }
                              return null;
                            },
                            errorText: genderError,
                          ),
                        ),
                        const SizedBox(width: 12.0),
                        Expanded(
                          child: _buildTextField(
                            label: 'DD/MM/YYYY',
                            controller: dobController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Date Of Birth is required';
                              }
                              return null;
                            },
                            errorText: dobError,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12.0),
                    _buildTextField(
                      label: 'Phone Number',
                      controller: phoneNumberController,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Phone Number is required';
                        }
                        return null;
                      },
                      errorText: phoneNumberError,
                    ),
                    const SizedBox(height: 12.0),
                    _buildTextField(
                      label: 'Email',
                      controller: emailController,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Email is required';
                        }
                        return null;
                      },
                      errorText: emailError,
                    ),
                    const SizedBox(height: 12.0),
                    _buildTextField(
                      label: 'Password',
                      controller: passwordController,
                      isPassword: true,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Password is required';
                        } else if (!_isPasswordValid(value)) {
                          return 'Password must contain at least one uppercase letter, one lowercase letter, one special character, and one digit';
                        }
                        return null;
                      },
                      errorText: passwordError,
                    ),
                    const SizedBox(height: 12.0),
                    _buildTextField(
                      label: 'Confirm Password',
                      controller: confirmPasswordController,
                      isPassword: true,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Confirm Password is required';
                        } else if (value != passwordController.text) {
                          return 'Passwords do not match';
                        }
                        return null;
                      },
                      errorText: confirmPasswordError,
                    ),
                    const SizedBox(height: 20.0),
                    ElevatedButton(
                      onPressed: () {
                        if (_validateForm()) {
                          // Perform registration logic
                        }
                      },
                      child: const Text('Register'),
                    ),
                    const SizedBox(height: 10.0),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/login');
                        },
                        child: RichText(
                          text: const TextSpan(
                            text: "Already have an account",
                            style: TextStyle(color: Colors.black),
                            children: [
                              WidgetSpan(
                                child: SizedBox(width: 5),
                              ),
                              TextSpan(
                                text: 'Log In',
                                style: TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    required String? Function(String?) validator,
    bool isPassword = false,
    String? errorText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
        ),
        TextFormField(
          controller: controller,
          obscureText: isPassword,
          validator: validator,
        ),
        if (errorText != null)
          Padding(
            padding: const EdgeInsets.only(top: 4.0),
            child: Text(
              errorText,
              style: const TextStyle(color: Colors.red),
            ),
          ),
      ],
    );
  }

  Widget _buildBackgroundImage() {
    return Image.asset(
      'assets/images/Art_Background.jpg',
      fit: BoxFit.cover,
      height: double.infinity,
      width: double.infinity,
    );
  }

  bool _validateForm() {
    setState(() {
      // Validate form fields and update error messages
      firstNameError =
          firstNameController.text.isEmpty ? 'First Name is required' : null;
      lastNameError =
          lastNameController.text.isEmpty ? 'Last Name is required' : null;
      genderError = genderController.text.isEmpty ? 'Gender is required' : null;
      dobError =
          dobController.text.isEmpty ? 'Date Of Birth is required' : null;
      phoneNumberError = phoneNumberController.text.isEmpty
          ? 'Phone Number is required'
          : null;
      emailError = emailController.text.isEmpty ? 'Email is required' : null;
      passwordError = passwordController.text.isEmpty
          ? 'Confirm Password is required'
          : passwordError = _isPasswordValid(passwordController.text)
              ? 'Password must contain at least one uppercase letter, one lowercase letter, one special character, and one digit'
              : null;
      confirmPasswordError = confirmPasswordController.text.isEmpty
          ? 'Confirm Password is required'
          : confirmPasswordController.text != passwordController.text
              ? 'Passwords do not match'
              : null;
    });

    // Check if all conditions are satisfied
    bool isFormValid = firstNameController.text.isNotEmpty &&
        lastNameController.text.isNotEmpty &&
        genderController.text.isNotEmpty &&
        dobController.text.isNotEmpty &&
        phoneNumberController.text.isNotEmpty &&
        emailController.text.isNotEmpty &&
        passwordController.text.isNotEmpty &&
        confirmPasswordController.text.isNotEmpty &&
        confirmPasswordController.text == passwordController.text;

    // If all conditions are satisfied, show a success dialog
    if (isFormValid) {
      _showSuccessDialog();
    }

    return isFormValid;
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return const AlertDialog(
          title: Text('Success'),
          content: Text('You have successfully registered.'),
        );
      },
    );
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacementNamed(context, '/homepage');
    });
  }

  bool _isPasswordValid(String password) {
    RegExp regex =
        RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{4,}$');
    return regex.hasMatch(password);
  }
}

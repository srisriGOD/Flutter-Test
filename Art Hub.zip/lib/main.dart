import 'package:flutter/material.dart';
import 'screens/homepage/camera.dart';
import 'screens/homepage/homepage.dart';
import 'screens/homepage/newsfeed.dart';
import 'screens/homepage/profile.dart';
import 'screens/login/login_screen.dart';
import 'screens/registration/registration_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Artistic Connect',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegistrationScreen(),
        '/homepage': (context) => const HomePage(),
        '/newsfeed': (context) => const NewsFeedScreen(),
        '/camera': (context) => const CameraPage(),
        '/profile': (context) => const ProfilePage(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}

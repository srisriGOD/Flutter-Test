# Art Hub

Art Hub is a Flutter project that brings together artists and art enthusiasts in a creative community. Share your artwork, explore the creations of others, and connect with fellow artists.

## Features

- **News Feed:** Explore a dynamic news feed where artists can share their latest creations.
- **Take a Photo:** Capture and share your artistic moments with the community.
- **Profile:** Showcase your profile, view your posts, and connect with other artists.


## Installation

1. Ensure you have Flutter installed. If not, follow the [Flutter installation guide](https://flutter.dev/docs/get-started/install).
2. Clone this repository: `git clone https://github.com/your-username/artistic_connect.git`
3. Navigate to the project directory: `cd `
4. Run the app: `flutter run`

## Dependencies

- [carousel_slider](https://pub.dev/packages/carousel_slider): A carousel slider widget.
- [rolling_bottom_bar](https://pub.dev/packages/rolling_bottom_bar): An innovative rolling bottom navigation bar.
- [graphql_flutter](https://pub.dev/packages/graphql_flutter): A Flutter GraphQL client for making remote GraphQL queries.

## Contributing

We welcome contributions! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

## License

This project is licensed under the [MIT License](LICENSE).

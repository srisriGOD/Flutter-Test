

import 'package:flutter/material.dart';

//const primaryColor = Color(0xffEFDF00);
const white = Color(0xffffffff);
const black= Color(0xff000000);
const grey = Color(0xffD9D9D9);
const primaryColor = Color(0xffFFCC33);
const textColor=Color(0xff555555);
const labelTextColor=Color(0xff979699);
const inputTextColor=Color(0xff333333);
const errorTextColor = Color(0xffD13C21);
const boxColor=Color(0xFF31CF66);
const dashboardTextColor = Color(0xFF333333);
const textGrey=Color(0xFF555555);
const bgColor=Color(0xFFF5F5F5);
const hintColor=Color(0xff666666);
const searchHintColor=Color(0xFF999999);
const buttonTextColor = Color(0xFFE1A900);
const red = Color(0xffFF2B2B);
const colorNotInuse= Color(0x80F96057);
const greyBox=Color(0xFFEFEFEF);
const darkGrey=Color(0xff333333);
const colorInprogress=Color(0xFFFF8C28);
const colorCompleted= Color(0xFF5ACE56);
const colorNotDone=Color(0xFF31A3E1);





